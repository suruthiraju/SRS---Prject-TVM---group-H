from django.apps import AppConfig


class Us3Config(AppConfig):
    name = 'US3'
