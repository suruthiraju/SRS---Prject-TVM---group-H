from django.apps import AppConfig


class Us4Config(AppConfig):
    name = 'US4'
