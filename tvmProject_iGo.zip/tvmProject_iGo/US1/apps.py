from django.apps import AppConfig


class Us1Config(AppConfig):
    name = 'US1'
