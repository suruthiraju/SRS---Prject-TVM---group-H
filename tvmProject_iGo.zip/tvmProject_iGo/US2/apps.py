from django.apps import AppConfig


class Us2Config(AppConfig):
    name = 'US2'
