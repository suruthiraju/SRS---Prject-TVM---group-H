from django.apps import AppConfig


class Us5Config(AppConfig):
    name = 'US5'
